#include "Shape.h"


Shape::Shape(void)
{
}


Shape::~Shape(void)
{
}



Point Shape::GetPosition()
{
	return position;
}
